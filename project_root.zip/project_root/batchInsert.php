<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csvFile'])) {
    $filename = $_FILES['csvFile']['tmp_name'];

    if ($_FILES['csvFile']['size'] > 0) {
        $file = fopen($filename, 'r');
        $conn = new mysqli('127.0.0.1', 'root', 'Siddu@2005', 'university');

        if ($conn->connect_error) {
            die('Connection failed: ' . $conn->connect_error);
        }

        $rowCount = 0;
        $errors = [];

        while (($row = fgetcsv($file)) !== FALSE) {
            // Assuming the first column is the table name, and the rest are data values
            $table = strtolower(trim($row[0]));
            $data = array_slice($row, 1); // Rest of the data

            // Get the column names dynamically
            $query = "DESCRIBE $table";
            $columns = [];
            if ($result = $conn->query($query)) {
                while ($column = $result->fetch_assoc()) {
                    $columns[] = $column['Field'];
                }
                $result->free();
            } else {
                $errors[] = "Table '$table' does not exist.";
                continue;
            }

            // Build the INSERT statement
            $values = "'" . implode("','", array_map([$conn, 'real_escape_string'], $data)) . "'";
            $columnsList = implode(',', $columns);
            $sql = "INSERT INTO $table ($columnsList) VALUES ($values)";

            if ($conn->query($sql) === TRUE) {
                $rowCount++;
            } else {
                $errors[] = "Error inserting into '$table': " . $conn->error;
            }
        }

        fclose($file);
        $conn->close();

        // Display results
        echo "<h2>Batch Insertion Results</h2>";
        echo "<p>$rowCount rows successfully inserted.</p>";
        if (!empty($errors)) {
            echo "<h3>Errors:</h3>";
            echo "<ul>";
            foreach ($errors as $error) {
                echo "<li>$error</li>";
            }
            echo "</ul>";
        }
    } else {
        echo "<p>No file uploaded or file is empty.</p>";
    }
} else {
    echo "<p>Invalid request.</p>";
}
?>
