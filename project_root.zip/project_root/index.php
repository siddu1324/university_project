<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>University Project</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>University Database Management</h1>
    <form action="batchInsert.php" method="POST" enctype="multipart/form-data">
        <label for="csvFile">Upload CSV for All Tables:</label>
        <input type="file" name="csvFile" id="csvFile" accept=".csv" required>
        <br><br>
        <button type="submit">Insert Batch Data</button>
    </form>
</body>
</html>
